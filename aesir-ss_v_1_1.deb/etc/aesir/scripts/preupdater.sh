#!/usr/bin/env bash

mkdir /tmp/aesirupdater/

echo >> /tmp/aesirupdater/log
rm -f /tmp/aesirupdater/logfile.txt
touch /tmp/aesirupdater/logfile.txt

rm -r /tmp/aesirupdater
cp -r /etc/aesir/updater /tmp/aesirupdater
python3 /tmp/aesirupdater/updater/aesirUpdater.py


