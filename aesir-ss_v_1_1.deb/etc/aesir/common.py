import gi
import requests
import math
import base64
import threading
import webbrowser
from gi.repository import Gdk as gdk
from gi.repository import Gtk as gtk
from gi.repository import GdkPixbuf, GLib
from requests_toolbelt import MultipartEncoder, MultipartEncoderMonitor
from aesirwebrequest import GoogleSearchUploader

import PIL
from PIL import Image

gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('AppIndicator3', '0.1')
from parameters import CONF_FILE_INSTANCE
import os

from userNotifier import userNotifierData as notifydata, userNotifier, NOTIFIER_TYPES


from pathlib import Path


import time


def returnFormattedSavePrefix():
    pathMan = aesirPathManager()
    current_time = time.strftime("_%d_%m_%Y_%H_%M")
    file_path = pathMan.returnImageSavePath() + "screenshot" + current_time
    return file_path

def returnIconPath(image_name):

    x= str(os.path.dirname(os.path.realpath(__file__))) + "/" + CONF_FILE_INSTANCE["icons"]["folder"] + "/" + \
           CONF_FILE_INSTANCE["icons"]["icons"][image_name]
    print(x)
    return x

def returnNotifyOfSaveSS(image_path):
    notifyData = notifydata(CONF_FILE_INSTANCE['ScrenshotSave']["NotifierTitle"],
                                 NOTIFIER_TYPES.SCREENSHOT_SAVE,
                                 CONF_FILE_INSTANCE['ScrenshotSave']["NotifierBody"],
                                 CONF_FILE_INSTANCE['ScrenshotSave']["NotifierData"],
                                 CONF_FILE_INSTANCE['ScrenshotSave']["NotifierActions"],
                                 str(image_path))
    return notifyData

def notifyAndScreenShotSave(image_instance):
    if image_instance is not None:

        if type(image_instance) == PIL.Image.Image:
            image_path = returnFormattedSavePrefix() + '.png'
            image_instance.save(image_path)
            notify_instance = userNotifier(returnNotifyOfSaveSS(image_path))
            return image_path
        if type(image_instance) == gi.repository.GdkPixbuf.Pixbuf:
            image_path = returnFormattedSavePrefix() + '.png'
            image_instance.savev(image_path, "png", (), ())
            notify_instance = userNotifier(returnNotifyOfSaveSS(image_path))
            return image_path










class aesirPathManager:
    def __init__(self):
        pass

    def returnHomePath(self):
        return str(Path.home())

    def returnImageSavePath(self):

        directory = self.returnHomePath() + "/Aesir/"

        try:
            if not os.path.exists(directory):
                os.makedirs(directory)

            return directory
        except:
            return None

